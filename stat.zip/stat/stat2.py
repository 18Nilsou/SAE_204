# -*- coding: utf-8 -*-
"""
Created on Fri Apr 22 11:47:20 2022

@author: Nils Saadi
"""

import matplotlib.pyplot as plt
import pandas as pd

data = pd.read_csv("donnees-synop-essentielles-omm (7).csv")

groupement_par_mois = data.groupby("mois_de_l_annee")
liste_mois = []
for i in range (len(groupement_par_mois)):
    liste_mois.append(i+1)

groupement_par_region = data.groupby("region (name)")

paca = data.loc[data["region (name)"]=="Provence-Alpes-Côte d'Azur"]
paca_groupement_par_mois = paca.groupby("mois_de_l_annee")
paca_groupement_par_departement = paca.groupby("department (name)")


bouche_de_rhone = data.loc[data["department (name)"]=="Bouches-du-Rhône"]
bouche_de_rhone_groupement_par_mois = bouche_de_rhone.groupby("mois_de_l_annee")

"""
Stat a l'echelle de la France
"""
#la Temperature
data["Température (°C)"].plot.box(whis=[0,100],vert=False)
plt.title("Diagramme en boite des tempérarure en °C de toute la France")
plt.show()

#La pluie
data["Précipitations dans les 12 dernières heures"].plot.box(whis=[0,100],vert=False)
plt.title("Diagramme en boite des tempérarure en °C de toute la France")
plt.show()
print("Description des précipitations dans les 12 dernières heures avant le relever")
print(data["Précipitations dans les 12 dernières heures"].describe())


#Le vent
data["Vitesse du vent moyen 10 mn"].plot.box(whis=[0,100],vert=False)
plt.title("Diagramme en boite de la vitesse du vent sur toute la France")
plt.show()


#Graph en fonction du mois
plt.plot(liste_mois, groupement_par_mois["Température (°C)"].mean())
plt.plot(liste_mois, groupement_par_mois["Précipitations dans les 12 dernières heures"].mean())
plt.plot(liste_mois, groupement_par_mois["Vitesse du vent moyen 10 mn"].mean())
plt.title("Courbe de la temperature(1), precipitation(2) et vitesse du vent(3) en fonction du mois")
plt.legend("123")
plt.show()

"""
Stat a l'echelle des regions
"""

groupement_par_region["Précipitations dans les 12 dernières heures"].count().plot.pie(autopct = lambda z: str(round(z, 2)) + '%', pctdistance = 0.6)
plt.title("Repartion des précipitation par region en mm")
plt.show()

groupement_par_region["Température (°C)"].mean().plot.bar(width=0.8,edgecolor='black')
plt.title("Moyenne des temprérature en °C par région")
plt.show()

groupement_par_region["Vitesse du vent moyen 10 mn"].mean().plot.bar(width=0.5,edgecolor='black')
plt.title("Vitesse moyenne du vent en m/s par région")
plt.show()


"""
Regardons plus en detail la region PACA
"""

paca["Température (°C)"].plot.box(whis=[0,100],vert=False)
plt.title("Diagramme en boite des tempérarure en °C dans la region PACA")
plt.show()

#La pluie
paca["Précipitations dans les 12 dernières heures"].plot.box(whis=[0,100],vert=False)
plt.title("Diagramme en boite des tempérarure en °C dans la region PACA")
plt.show()
print("Description des précipitations dans les 12 dernières heures avant le relever dans la region PACA")
print(paca["Précipitations dans les 12 dernières heures"].describe())


#Le vent
paca["Vitesse du vent moyen 10 mn"].plot.box(whis=[0,100],vert=False)
plt.title("Diagramme en boite de la vitesse du vent dans le region PACA")
plt.show()

plt.plot(liste_mois, paca_groupement_par_mois["Température (°C)"].mean())
plt.plot(liste_mois, paca_groupement_par_mois["Précipitations dans les 12 dernières heures"].mean())
plt.plot(liste_mois, paca_groupement_par_mois["Vitesse du vent moyen 10 mn"].mean())
plt.title("Courbe de la temperature(1), precipitation(2) et vitesse du vent(3) en fonction du mois dans la region PACA")
plt.legend("123")
plt.show()

paca_groupement_par_departement["Température (°C)"].mean().plot.bar(width=0.8,edgecolor='black')
plt.title("Moyenne des temprérature en °C dans le region PACA")
plt.show()

paca_groupement_par_departement["Précipitations dans les 12 dernières heures"].mean().plot.bar(width=0.8,edgecolor='black')
plt.title("Moyenne des precipitatio en mm dans le region PACA")
plt.show()


"""
Regardons plus en detail dans le departement des bouche du rhone
"""
bouche_de_rhone["Température (°C)"].plot.box(whis=[0,100],vert=False)
plt.title("Diagramme en boite des tempérarure en °C dans les Bouches-du-Rhône")
plt.show()

#La pluie
bouche_de_rhone["Précipitations dans les 12 dernières heures"].plot.box(whis=[0,100],vert=False)
plt.title("Diagramme en boite des tempérarure en °C dans dans les Bouches-du-Rhône")
plt.show()
print("Description des précipitations dans les 12 dernières heures avant le relever dans les Bouches-du-Rhône")
print(bouche_de_rhone["Précipitations dans les 12 dernières heures"].describe())

bouche_de_rhone_groupement_par_mois["Précipitations dans les 12 dernières heures"].count().plot.pie(autopct = lambda z: str(round(z, 2)) + '%', pctdistance = 0.6)
plt.title("Repartion des précipitation dans les bouche du rhone par mois")
plt.show()

#Le vent
bouche_de_rhone["Vitesse du vent moyen 10 mn"].plot.box(whis=[0,100],vert=False)
plt.title("Diagramme en boite de la vitesse du vent dans les Bouches-du-Rhône")
plt.show()

bouche_de_rhone["Rafale sur les 10 dernières minutes"].plot.box(whis=[0,100],vert=False)
plt.title("Diagramme en boite des rafales de vent dans les Bouches-du-Rhône")
plt.show()

plt.scatter(bouche_de_rhone["Direction du vent moyen 10 mn"],bouche_de_rhone["Vitesse du vent moyen 10 mn"])
plt.title("nuage de point de la vitesse du vent en fonction de la direction")
plt.show()

moyenne_bouche_de_rhone_groupement_par_mois = bouche_de_rhone_groupement_par_mois.mean()
moyenne_bouche_de_rhone_groupement_par_mois.plot.bar(y=["Température (°C)","Précipitations dans les 12 dernières heures","Vitesse du vent moyen 10 mn"], secondary_y = "Température (°C)",legend = None)
plt.title("Diagramme de la temperature(bleu-droite), precipitation(orange-gauche) et vitesse du vent(vert-gauche) en fonction du mois dans les Bouches-du-Rhône")

plt.show()

plt.plot(liste_mois, bouche_de_rhone_groupement_par_mois["Température (°C)"].mean())
plt.plot(liste_mois, bouche_de_rhone_groupement_par_mois["Précipitations dans les 12 dernières heures"].mean())
plt.plot(liste_mois, bouche_de_rhone_groupement_par_mois["Vitesse du vent moyen 10 mn"].mean())
plt.title("Courbe de la temperature(1), precipitation(2) et vitesse du vent(3) en fonction du mois dans les Bouches-du-Rhône")
plt.legend("123")
plt.show()

